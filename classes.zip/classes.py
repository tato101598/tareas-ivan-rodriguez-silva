class covid19(): 
    def __init__(self, estado, Casosconfirmados, Casosnegativos, Decesos): 
        self.estado = estado 
        self.Casosconfirmados = Casosconfirmados  
        self.Casosnegativos =  Casosnegativos 
        self.Decesos = Decesos
        
    def presentar(self):
        presentacion = ("Covid por estado:{}, Casos confirmados:{}, Casos negativos:{}, Decesos:{} ") 
        print(presentacion.format( self.estado, self.Casosconfirmados, self.Casosnegativos, self.Decesos  )) 

Persona1 = covid19("Tamaulipas", 29057, 36222, 2218) 
Persona1.presentar() 

class covid19dos():
    def __init__ (self, estado, Casosconfirmados, Casosnegativos, Decesos):
        self.estado = estado
        self.Casosconfirmados = Casosconfirmados
        self.Casosnegativos =  Casosnegativos
        self.Decesos = Decesos
    def presentar(self):
        presentacion = ("Covid por estado:{}, Casos confirmados:{}, Casos negativos:{}, Decesos:{} ") 
        print(presentacion.format( self.estado, self.Casosconfirmados, self.Casosnegativos, self.Decesos  )) 

Persona1 = covid19dos ("Veracruz", 33480, 18276, 4369) 
Persona1.presentar()

class covid19tres():
    def __init__ (self, estado, Casosconfirmados, Casosnegativos, Decesos):
        self.estado = estado
        self.Casosconfirmados = Casosconfirmados
        self.Casosnegativos =  Casosnegativos
        self.Decesos = Decesos
    def presentar(self):
        presentacion = ("Covid por estado:{}, Casos confirmados:{}, Casos negativos:{}, Decesos:{} ") 
        print(presentacion.format( self.estado, self.Casosconfirmados, self.Casosnegativos, self.Decesos  )) 

Persona1 = covid19dos ("Yucatan", 18451, 17358, 1599) 
Persona1.presentar() 

  
