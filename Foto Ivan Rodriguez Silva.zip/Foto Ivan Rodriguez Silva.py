import cv2
import tkinter
import Image, ImageTk
from tkinter import *

root=tkinter.Tk()
root.title('photo')
root.geometry('720x420')

def iniciar():
    go()
def go():
    camara= cv2.VideoCapture(0)
    leido,frame=camara.read()
    if leido==True:
        cv2.imwrite('Ivanrdzsilva.png',frame)
        print('La foto ha sido tomada exitosamente')
    else:
        print('Error Camara no existe o esta apagada o desconfigurada')
        camara.release()
    foto=PhotoImage(file='Ivanrdzsilva.png')
    fondo=Label(root,image=foto).place(x=0,y=0)
    texto=StringVar()
    texto.set("¿Desea otra foto?")
    eti=Label(root,textvariable=texto).place(x=420,y=325)
    boton=Button(root,text='SI',command=iniciar).place(x=420,y=380)
    boton2=Button(root,text='NO',command=root.destroy).place(x=480,y=380)
    
    root.mainloop()
go()


