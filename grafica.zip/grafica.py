from math import *
from numpy import *
from matplotlib import pyplot

def=plot()
t = arange(0.1, 20, 0.1)

y1 = sin(t)/t
y2 = sin(t)*exp(-t)
p1, p2 = plot(t, y1, t, y2)

texto1 = text(2, 0.6, r'S\frac{\sin(x)}{x}}{x}S', fontsize=20)
texto2 = text(13, 0.2, r'S\sin(x) \cdot e^{-x}S', fontsize=16)

grid()

title('grafica de dos funciones')
xlabel('Tiempo/ s')
ylabel('Amplitud / cm')
p1label('plot')
p2label('plot')
show()
