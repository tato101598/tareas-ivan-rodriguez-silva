import mysql.connector
import json
from tkinter import *
from tkinter.ttk import *

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="tercer parcial")

def estado():
    print("confirmados","negativos","sospechosos","defunciones","recuprados","activos")
    if combo.get()=='Tamaulipas':
        mycursor = mydb.cursor()
        sql = "SELECT \
              tamaulipas.Estado AS ala, \
              estados.Num_Est AS fav, \
              tamaulipas.Confirmados AS Conf, \
              tamaulipas.Negativos AS Neg, \
              tamaulipas.Sospechosos AS Sosp, \
              tamaulipas.Defunciones AS Def, \
              tamaulipas.Recuperados AS Rec, \
              tamaulipas.Activos AS Act \
              FROM tamaulipas \
              INNER JOIN estados ON tamaulipas.Numero=estados.Num_Est \
              where Num_Est='25'"
        mycursor.execute(sql)
        myresult = mycursor.fetchall()
        for x in myresult:
            print("Estos son los casos en Tamaulipas:")
            print(x)
            if combo.get()=='Tlaxcala':
                mycursor = mydb.cursor()
                sql = "SELECT \
                       tlaxcala.Estado AS ala, \
                       estados.Num_Est AS fav, \
                       tlaxcala.Confirmados AS Conf, \
                       tlaxcala.Negativos AS Neg, \
                       tlaxcala.Sospechosos AS Sosp, \
                       tlaxcala.Defunciones AS Def, \
                       tlaxcala.Recuperados AS Rec, \
                       tlaxcala.Activos AS Act \
                       FROM tlaxcala \
                       INNER JOIN estados ON tlaxcala.Numero=estados.Num_Est \
                       where Num_Est='26'"
                mycursor.execute(sql)
                myresult = mycursor.fetchall()
                for x in myresult:
                    print("Estos son los casos en Tlaxcala:")
                    print(x)

            if combo.get()=='Veracruz':
                mycursor = mydb.cursor()
                sql = "SELECT \
                      veracruz.Estado AS ala, \
                      estados.Numero AS fav, \
                      veracruz.Confirmados AS Conf, \
                      veracruz.Negativos AS Neg, \
                      veracruz.Sospechosos AS Sosp, \
                      veracruz.Defunciones AS Def, \
                      veracruz.Recuperados AS Rec, \
                      veracruz.Activos AS Act \
                      FROM veracruz \
                      INNER JOIN estados ON veracruz.Numero=estados.Numero \
                      where Numero='27'"
                mycursor.execute(sql)
                myresult = mycursor.fetchall()
                for x in myresult:
                    print("Estos son los casos en Veracruz")
                    print(x)
            if combo.get()=='Yucatan':
                mycursor = mydb.cursor()
                sql = "SELECT \
                      yucatan.Estado AS ala, \
                      estados.Numero AS fav, \
                      yucatan.Confirmados AS Conf, \
                      yucatan.Negativos AS Neg, \
                      yucatan.Sospechosos AS Sosp, \
                      yucatan.Defunciones AS Def, \
                      yucatan.Recuperados AS Rec, \
                      yucatan.Activos AS Act \
                      FROM yucatan \
                      INNER JOIN estados ON yucatan.Numero=estados.Numero \
                      where Numero='28'"
                mycursor.execute(sql)
                myresult = mycursor.fetchall()
                for x in myresult:
                    print("Estos son los casos en Yucatan:")
                    print(x)
            if combo.get()=='Zacatecas':
                mycursor = mydb.cursor()
                sql = "SELECT \
                      zacatecas.Estado AS ala, \
                      estados.Numero AS fav, \
                      zacatecas.Confirmados AS Conf, \
                      zacatecas.Negativos AS Neg, \
                      zacatecas.Sospechosos AS Sosp, \
                      zacatecas.Defunciones AS Def, \
                      zacatecas.Recuperados AS Rec, \
                      zacatecas.Activos AS Act \
                      FROM zacatecas \
                      INNER JOIN estados ON zacatecas.Numero=estados.Numero \
                      where Numero='29'"
                mycursor.execute(sql)
                myresult = mycursor.fetchall()
                for x in myresult:
                    print("Estos son los casos en Zacatecas")
                    print(x)



windows = Tk()
windows.title('Datos del COVID-19')
windows.geometry("300x300")



texto=StringVar()
texto.set ('Estado: ')

combo = Combobox(windows)
combo.place(x=50,y=250)
combo['values'] = [
    'Tamaulipas',
    'Tlaxcala',
    'Veracruz',
    'Yucatan',
    'Zacatecas'
    ]
combo.current()


btn=Button(windows,command=estado,text='entrar')
etiqueta=Label(windows,textvariable=texto)
etiqueta.place(x=40,y=200)


btn.place(x=75,y=150)


windows.mainloop()
input(" ")
